jQuery( document ).ready( function( $ ){

	// JS script ...

} );